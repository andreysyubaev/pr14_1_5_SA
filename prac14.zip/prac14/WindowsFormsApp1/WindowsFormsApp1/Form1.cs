﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonStack_Click_1(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(textBox1.Text);
            if (!Digit(n.ToString()))
                MessageBox.Show("введите n только цифрами");
            else if (WhiteSpace(n.ToString()))
                MessageBox.Show("введите n");
            else
            {
            Stack<int> stack = new Stack<int>();
            for (int i = 1; i <= n; i++)
            {
                stack.Push(i);
            }

            listBox1.Items.Clear();
            listBox1.Items.Add($"Размерность стека: {stack.Count}");
            listBox1.Items.Add($"Верхний элемент стека: {stack.Peek()}");
            listBox1.Items.Add($"Содержимое стека: {string.Join(" ", stack)}");
            listBox1.Items.Add($"Новая размерность стека: {stack.Count}");
            stack.Clear();
            }
        }

        private bool Digit(string text)
        {
            for (int i = 0; i < text.Length; i++)
            {
                if (!char.IsDigit(text[i]))
                    return false;
            }
            return true;
        }

        private void buttonCheckBalance_Click_1(object sender, EventArgs e)
        {
            string expression = textBox2.Text;
            if (WhiteSpace(expression))
                MessageBox.Show("введите n");
            else
            {
                if (!Pr(expression))
                {
                    listBox2.Items.Clear();
                    listBox2.Items.Add("Выражение содержит недопустимые символы");
                    listBox2.Items.Add("Пример: (2 + 3) * (4 - 1)");
                    return;
                }

                Stack<int> stack = new Stack<int>();
                bool balanced = true;
                StringBuilder fixedvir = new StringBuilder(expression);
                List<int> openSkop = new List<int>();
                List<int> closeSkop = new List<int>();

                for (int i = 0; i < expression.Length; i++)
                {
                    char ch = expression[i];
                    if (ch == '(')
                    {
                        stack.Push(i);
                    }
                    else if (ch == ')')
                    {
                        if (stack.Count == 0)
                        {
                            balanced = false;
                            closeSkop.Add(i);
                        }
                        else
                        {
                            stack.Pop();
                        }
                    }
                }

                while (stack.Count > 0)
                {
                    openSkop.Add(stack.Pop());
                    balanced = false;
                }

                listBox2.Items.Clear();

                if (balanced)
                {
                    listBox2.Items.Add("Скобки сбалансированы");
                }
                else
                {
                    if (openSkop.Count > 0)
                    {
                        foreach (int pos in openSkop)
                        {
                            listBox2.Items.Add($"Лишняя ( скобка в позиции: {pos + 1}");
                            fixedvir.Insert(pos + 1, ")");
                        }
                    }

                    if (closeSkop.Count > 0)
                    {
                        foreach (int pos in closeSkop)
                        {
                            listBox2.Items.Add($"Лишняя ) скобка в позиции: {pos + 1}");
                            fixedvir.Remove(pos, 1);
                        }
                    }

                    listBox2.Items.Add("Исправленное выражение");
                    listBox2.Items.Add(fixedvir.ToString());

                    File.WriteAllText("t1.txt", fixedvir.ToString());
                }
            }
        }

        private bool Pr(string text)
        {
            foreach (char ch in text)
            {
                if (!char.IsDigit(ch) && ch != '+' && ch != '-' && ch != '*' && ch != '/' && ch != '(' && ch != ')' && !char.IsWhiteSpace(ch))
                {
                    return false;
                }
            }
            return true;
        }

        private void buttonSortPeople_Click_1(object sender, EventArgs e)
        {
            if (!File.Exists("people.txt"))
            {
                MessageBox.Show("файл отсутвует!");
                buttonSortPeople.Enabled = false;
            }
            else
            {
                List<string> lines = File.ReadAllLines("people.txt").ToList();
                List<string> men40 = new List<string>();
                List<string> bol40 = new List<string>();

                foreach (string line in lines)
                {
                    string[] parts = line.Split(' ');
                    if (parts.Length >= 5 && int.TryParse(parts[3], out int age) && int.TryParse(parts[4], out int weight))
                    {
                        if (age < 40)
                        {
                            men40.Add(line);
                        }
                        else
                        {
                            bol40.Add(line);
                        }
                    }
                    else
                    {
                        listBox3.Items.Add($"Неправильный формат строки: {line}");
                    }
                }

                listBox3.Items.Clear();
                listBox3.Items.Add("Люди младше 40 лет:");
                listBox3.Items.AddRange(men40.ToArray());
                listBox3.Items.Add("Люди старше 40 лет:");
                listBox3.Items.AddRange(bol40.ToArray());
            }
        }

        private bool WhiteSpace(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return true;
            return false;
        }
    }
}
